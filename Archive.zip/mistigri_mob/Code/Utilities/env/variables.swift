//
//  server.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 08/03/2025.
//

import Foundation

let baseUrl = ProcessInfo.processInfo.environment["baseURL"] ?? ""
