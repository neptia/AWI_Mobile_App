//
//  Test.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 18/03/2025.
//

import SwiftUI

struct Test: View {
    var body: some View {
        Text("Hello, World!")
    }
}
