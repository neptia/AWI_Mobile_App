//
//  newSessionResponse.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 22/03/2025.
//

struct newSessionResponse: Decodable {
    let message: String;
}
