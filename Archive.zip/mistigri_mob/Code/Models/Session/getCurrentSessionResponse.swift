//
//  getCurrentSessionResponse.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 21/03/2025.
//

struct getCurrentSessionResponse: Decodable {
    let currentSession: Session
}
