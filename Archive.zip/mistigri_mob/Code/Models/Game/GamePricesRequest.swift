//
//  GamePricesRequest.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 15/03/2025.
//

import Foundation

struct GamePricesRequest: Encodable {
    let game_id: String
}
