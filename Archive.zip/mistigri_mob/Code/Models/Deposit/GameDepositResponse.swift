//
//  GameDepositResponse.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 17/03/2025.
//

import SwiftUI

struct GameDepositResponse: Decodable {
    var message: String
}
