//
//  sellerIdRequest.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 24/03/2025.
//

struct sellerIdRequest: Codable {
    let seller_id: String;
}
