//
//  GameCheckoutResponsePos.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 19/03/2025.
//

struct GameCheckoutResponsePositive: Decodable {
    var message: String
}
