//
//  GameStockBySellerRequest.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 21/03/2025.
//

import SwiftUI

struct GameStockBySellerRequest: Encodable {
    let seller_id: String
}
