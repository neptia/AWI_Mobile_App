//
//  SellerReceiptsRequest.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 25/03/2025.
//

struct SellerReceiptsRequest: Codable {
    let seller_id: String
}
