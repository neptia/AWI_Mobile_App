//
//  messageResponse.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 24/03/2025.
//

struct messageResponse: Decodable {
    let message: String
}
