//
//  updateCommissionFeeRequest.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 24/03/2025.
//

struct updateCommissionFeeRequest: Codable {
    var state: String;
    var amount: Double
}
