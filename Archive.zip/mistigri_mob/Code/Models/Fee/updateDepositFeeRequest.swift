//
//  updateDepositFee.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 24/03/2025.
//

struct updateDepositFeeRequest: Codable {
    var state: String;
    var amount: Double
}
