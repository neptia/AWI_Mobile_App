//
//  LoginRequest.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 08/03/2025.
//

import Foundation

struct LoginRequest: Encodable {
    let email: String
    let password: String
}
