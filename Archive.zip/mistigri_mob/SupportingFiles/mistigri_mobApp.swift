//
//  mistigri_mobApp.swift
//  mistigri_mob
//
//  Created by Poomedy Rungen on 08/03/2025.
//

import SwiftUI

@main
struct MistigriMobApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

